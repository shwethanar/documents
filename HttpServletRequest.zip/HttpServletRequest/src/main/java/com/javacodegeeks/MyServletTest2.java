package com.javacodegeeks;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public class MyServletTest2 {

	@Mock
	HttpServletRequest request;

	@Mock
	HttpServletResponse response;

	@Before
	public void setUp() throws Exception {

		//https://stackoverflow.com/questions/37314469/how-to-mock-httpservletrequest-with-headers
		// define the headers you want to be returned
		Map<String, String> headers = new HashMap<>();
		headers.put(null, "HTTP/1.1 200 OK");
		headers.put("Content-Type", "text/html");

		// create an Enumeration over the header keys
		Enumeration<String> headerNames = Collections.enumeration(headers.keySet());

		// mock HttpServletRequest
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		// mock the returned value of request.getHeaderNames()
		when(request.getHeaderNames()).thenReturn(headerNames);

		System.out.println("demonstrate output of request.getHeaderNames()");
		while (headerNames.hasMoreElements()) {
		    System.out.println("header name: " + headerNames.nextElement());
		}
	//	https://stackoverflow.com/questions/36615330/mockito-doanswer-vs-thenreturn   
		// mock the returned value of request.getHeader(String name)
		Mockito.doAnswer(new Answer<String>() {
		    @Override
		    public String answer(InvocationOnMock invocation) throws Throwable {
		        Object[] args = invocation.getArguments();
		        return headers.get((String) args[0]);
		    }
		}).when(request).getHeader("Content-Type");

		System.out.println("demonstrate output of request.getHeader(String name)");
		String headerName = "Content-Type";
		System.out.printf("header name: [%s]   value: [%s]%n", 
		        headerName, request.getHeader(headerName));
		}
		
		
	

	@Test
	public void testFullName() throws IOException, ServletException {

		
		
		
		when(request.getParameter("fn")).thenReturn("Shwetha");
		when(request.getParameter("ln")).thenReturn("Narayan");

		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		
		when(response.getWriter()).thenReturn(pw);

		MyServlet myServlet =new MyServlet();
		myServlet.doGet(request, response);
		
		String result = sw.getBuffer().toString().trim();
		assertEquals(result, new String("Full Name: Shwetha Narayan"));

	}
}
